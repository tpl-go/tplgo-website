"use client";

import { FormEvent, useMemo, useState } from "react";
import { CalendarDays, MapPin, Search, Sparkles, Users } from "lucide-react";
import {
  getTiyaCitySuggestions,
  type TiyaMockCity,
} from "@/app/lib/ecosystem/planner/plannerCityData";
import type { TiyaTripIntent } from "@/app/lib/ecosystem/planner/plannerTypes";

type TiyaDesktopEntryHeroProps = {
  initialIntent: TiyaTripIntent;
  onSubmit: (intent: TiyaTripIntent) => void;
  isGenerating?: boolean;
};

const budgetVibes = ["Economy", "Standard", "Premium", "Luxury"];
const styleVibes = [
  "Family",
  "Couple",
  "Friends",
  "Solo",
  "Adventure",
  "Spiritual",
  "Luxury",
  "Workation",
];

function CityComboBox({
  label,
  value,
  placeholder,
  onChange,
}: {
  label: string;
  value: string;
  placeholder: string;
  onChange: (value: string) => void;
}) {
  const [isOpen, setIsOpen] = useState(false);
  const suggestions = useMemo(() => getTiyaCitySuggestions(value), [value]);

  function selectCity(city: TiyaMockCity) {
    onChange(city.name);
    setIsOpen(false);
  }

  return (
    <label className="relative block">
      <span className="mb-1.5 block text-[10px] font-black uppercase tracking-[0.16em] text-white/45">
        {label}
      </span>

      <div className="relative">
        <Search
          size={15}
          className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-white/35"
        />
        <input
          value={value}
          onChange={(event) => {
            onChange(event.target.value);
            setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          onBlur={() => window.setTimeout(() => setIsOpen(false), 120)}
          className="h-11 w-full rounded-2xl border border-white/15 bg-white/[0.07] py-2.5 pl-10 pr-4 text-[15px] font-black text-white outline-none transition placeholder:text-white/30 focus:border-orange-300/70 focus:bg-white/10"
          placeholder={placeholder}
          autoComplete="off"
        />
      </div>

      {isOpen && suggestions.length ? (
        <div className="absolute left-0 right-0 top-[calc(100%+8px)] z-40 overflow-hidden rounded-2xl border border-white/20 bg-white text-slate-950 shadow-[0_22px_60px_rgba(2,6,23,0.22)]">
          {suggestions.map((city) => (
            <button
              key={city.name}
              type="button"
              onMouseDown={(event) => event.preventDefault()}
              onClick={() => selectCity(city)}
              className="flex w-full items-center justify-between gap-3 px-4 py-3 text-left transition hover:bg-orange-50"
            >
              <span>
                <span className="block text-sm font-black text-slate-950">
                  {city.name}
                </span>
                <span className="block text-xs font-bold text-slate-500">
                  {city.region}
                </span>
              </span>
              <span className="rounded-full bg-blue-50 px-2.5 py-1 text-[10px] font-black uppercase tracking-[0.12em] text-blue-700">
                mock
              </span>
            </button>
          ))}
        </div>
      ) : null}
    </label>
  );
}

export default function TiyaDesktopEntryHero({
  initialIntent,
  onSubmit,
  isGenerating = false,
}: TiyaDesktopEntryHeroProps) {
  const [intent, setIntent] = useState<TiyaTripIntent>(initialIntent);

  const travellerCount = intent.adults + intent.children + intent.seniors;

  const routeLabel = `${intent.fromCity || "Origin"} to ${
    intent.toCity || "Destination"
  }`;

  const dateLabel = useMemo(() => {
    if (!intent.startDate || !intent.endDate) return "Dates flexible";
    return `${intent.startDate} to ${intent.endDate}`;
  }, [intent.endDate, intent.startDate]);

  const summaryCards: Array<{
    label: string;
    value: string;
    icon: typeof MapPin;
  }> = [
    { label: "Route", value: routeLabel, icon: MapPin },
    { label: "Dates", value: dateLabel, icon: CalendarDays },
    { label: "Travellers", value: `${travellerCount}`, icon: Users },
  ];

  function updateIntent<K extends keyof TiyaTripIntent>(
    key: K,
    value: TiyaTripIntent[K]
  ) {
    setIntent((current) => ({ ...current, [key]: value }));
  }

  function updateTravellers(nextValue: number) {
    updateIntent("adults", Math.max(1, Math.min(20, nextValue)));
    updateIntent("children", 0);
    updateIntent("seniors", 0);
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    onSubmit(intent);
  }

  return (
    <section className="relative overflow-hidden border-b border-white/70 bg-[#061839] text-white">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_18%_12%,rgba(34,211,238,0.16),transparent_30%),radial-gradient(circle_at_86%_10%,rgba(249,115,22,0.18),transparent_28%),linear-gradient(135deg,#061839_0%,#0a1e42_48%,#111827_100%)]" />
      <div className="absolute left-1/2 top-0 h-px w-[min(820px,84vw)] -translate-x-1/2 bg-gradient-to-r from-transparent via-cyan-200/70 to-transparent" />

      <div className="relative mx-auto grid max-w-7xl gap-7 px-6 py-8 lg:grid-cols-[0.92fr_1.08fr] lg:items-center lg:px-8 lg:py-10">
        <div className="max-w-2xl">
          <div className="inline-flex items-center gap-2 rounded-full border border-cyan-200/20 bg-white/10 px-4 py-1.5 text-[11px] font-black uppercase tracking-[0.18em] text-cyan-100 backdrop-blur-xl">
            <Sparkles
              size={14}
              className={isGenerating ? "animate-pulse" : undefined}
            />
            Tiya AI Travel Brief
          </div>

          <h1 className="mt-4 text-[42px] font-black leading-[1.02] tracking-normal lg:text-[44px]">
            Choose your journey path with{" "}
            <span className="bg-gradient-to-r from-orange-200 via-orange-300 to-amber-300 bg-clip-text text-transparent">
              Tiya
            </span>
          </h1>

          <p className="mt-4 max-w-xl text-[15px] font-semibold leading-6 text-white/65">
            Give Tiya the essential trip brief. The workspace opens only after
            route choices are generated and a journey path is selected.
          </p>

          <div className="mt-5 grid max-w-xl gap-2 sm:grid-cols-3">
            {summaryCards.map(({ label, value, icon: CardIcon }) => (
              <div
                key={label}
                className="rounded-2xl border border-white/10 bg-white/[0.08] p-3 backdrop-blur-xl"
              >
                <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.14em] text-cyan-100">
                  <CardIcon size={13} />
                  {label}
                </div>
                <p className="mt-1.5 truncate text-sm font-black text-white">
                  {value}
                </p>
              </div>
            ))}
          </div>
        </div>

        <form
          onSubmit={handleSubmit}
          className="rounded-[1.7rem] border border-white/12 bg-white/[0.08] p-4 shadow-[0_24px_80px_rgba(2,6,23,0.26)] backdrop-blur-2xl"
        >
          <div className="grid gap-3">
            <div className="grid gap-3 lg:grid-cols-2">
              <CityComboBox
                label="From"
                value={intent.fromCity}
                placeholder="Delhi"
                onChange={(value) => updateIntent("fromCity", value)}
              />
              <CityComboBox
                label="To"
                value={intent.toCity}
                placeholder="Jaipur"
                onChange={(value) => updateIntent("toCity", value)}
              />
            </div>

            <div className="grid gap-3 lg:grid-cols-3">
              <label>
                <span className="mb-1.5 block text-[10px] font-black uppercase tracking-[0.16em] text-white/45">
                  Start Date
                </span>
                <input
                  type="date"
                  value={intent.startDate}
                  onChange={(event) =>
                    updateIntent("startDate", event.target.value)
                  }
                  className="h-11 w-full rounded-2xl border border-white/15 bg-white/[0.07] px-4 py-2.5 text-sm font-black text-white outline-none [color-scheme:dark] focus:border-orange-300/70"
                />
              </label>

              <label>
                <span className="mb-1.5 block text-[10px] font-black uppercase tracking-[0.16em] text-white/45">
                  End Date
                </span>
                <input
                  type="date"
                  value={intent.endDate}
                  onChange={(event) =>
                    updateIntent("endDate", event.target.value)
                  }
                  className="h-11 w-full rounded-2xl border border-white/15 bg-white/[0.07] px-4 py-2.5 text-sm font-black text-white outline-none [color-scheme:dark] focus:border-orange-300/70"
                />
              </label>

              <label>
                <span className="mb-1.5 block text-[10px] font-black uppercase tracking-[0.16em] text-white/45">
                  Travellers
                </span>
                <input
                  type="number"
                  min={1}
                  max={20}
                  value={travellerCount}
                  onChange={(event) =>
                    updateTravellers(Number(event.target.value) || 1)
                  }
                  className="h-11 w-full rounded-2xl border border-white/15 bg-white/[0.07] px-4 py-2.5 text-sm font-black text-white outline-none focus:border-orange-300/70"
                />
              </label>
            </div>

            <div className="grid gap-3 lg:grid-cols-2">
              <label>
                <span className="mb-1.5 block text-[10px] font-black uppercase tracking-[0.16em] text-white/45">
                  Budget vibe
                </span>
                <select
                  value={intent.budgetTier}
                  onChange={(event) =>
                    updateIntent("budgetTier", event.target.value)
                  }
                  className="h-11 w-full rounded-2xl border border-white/20 bg-white px-4 py-2.5 text-sm font-black text-slate-950 outline-none shadow-[0_10px_26px_rgba(2,6,23,0.12)] focus:border-orange-300/70"
                >
                  {budgetVibes.map((budget) => (
                    <option
                      key={budget}
                      value={budget}
                      className="bg-white text-slate-950"
                    >
                      {budget}
                    </option>
                  ))}
                </select>
              </label>

              <label>
                <span className="mb-1.5 block text-[10px] font-black uppercase tracking-[0.16em] text-white/45">
                  Travel style
                </span>
                <select
                  value={intent.travelStyle}
                  onChange={(event) =>
                    updateIntent("travelStyle", event.target.value)
                  }
                  className="h-11 w-full rounded-2xl border border-white/20 bg-white px-4 py-2.5 text-sm font-black text-slate-950 outline-none shadow-[0_10px_26px_rgba(2,6,23,0.12)] focus:border-orange-300/70"
                >
                  {styleVibes.map((style) => (
                    <option
                      key={style}
                      value={style}
                      className="bg-white text-slate-950"
                    >
                      {style}
                    </option>
                  ))}
                </select>
              </label>
            </div>

            <button
              type="submit"
              disabled={isGenerating}
              className="mt-1 inline-flex min-h-11 items-center justify-center gap-2 rounded-full bg-gradient-to-r from-[#ff7b00] via-[#ff9500] to-[#ffb300] px-6 py-3 text-[15px] font-black text-white shadow-[0_16px_42px_rgba(255,123,0,0.3)] transition hover:-translate-y-0.5 disabled:cursor-wait disabled:opacity-75"
            >
              <Sparkles
                size={17}
                className={isGenerating ? "animate-pulse" : undefined}
              />
              {isGenerating ? "Tiya is scanning routes" : "Generate Routes"}
            </button>
          </div>
        </form>
      </div>
    </section>
  );
}