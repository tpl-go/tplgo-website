"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Compass,
  Mountain,
  Route,
  Sparkles,
  X,
} from "lucide-react";
import { saveRouteWorkspacePayload } from "@/app/lib/ecosystem/planner/plannerRouteWorkspaceHandoff";
import type {
  TiyaGeneratedPlan,
  TiyaRouteOption,
  TiyaTripIntent,
} from "@/app/lib/ecosystem/planner/plannerTypes";

type TiyaRouteIntelligenceProps = {
  routeOptions: TiyaRouteOption[];
  isGenerating?: boolean;
  selectedRouteId?: TiyaRouteOption["id"];
  selectionConfirmed?: boolean;
  tripIntent?: TiyaTripIntent;
  generatedPlan?: TiyaGeneratedPlan;
  onSelectedRouteChange?: (routeId: TiyaRouteOption["id"]) => void;
};

type PreviewTab =
  | "Overview"
  | "Itinerary"
  | "Cost"
  | "Alerts"
  | "Stay"
  | "Experiences"
  | "Creator";

const previewTabs: PreviewTab[] = [
  "Overview",
  "Itinerary",
  "Cost",
  "Alerts",
  "Stay",
  "Experiences",
  "Creator",
];

const riskStyles: Record<TiyaRouteOption["riskLevel"], string> = {
  Low: "bg-emerald-50 text-emerald-700 border-emerald-100",
  Medium: "bg-orange-50 text-orange-700 border-orange-100",
  High: "bg-rose-50 text-rose-700 border-rose-100",
};

type RoutePersonality = {
  accent: string;
  base: string;
  gapGlow: string;
  glow: string;
  badge: string;
  icon: string;
  title: string;
  line: string;
  terrain: string;
};

const fallbackPersonalities: RoutePersonality[] = [
  {
    accent: "border-orange-300/60 bg-orange-500/[0.08]",
    base: "bg-[linear-gradient(135deg,rgba(28,25,23,0.94),rgba(67,36,18,0.72)),radial-gradient(circle_at_8%_18%,rgba(251,146,60,0.18),transparent_32%)]",
    gapGlow: "bg-gradient-to-r from-transparent via-orange-300/35 to-transparent",
    glow: "shadow-[0_20px_64px_rgba(249,115,22,0.18)]",
    badge: "bg-orange-300/15 text-orange-100 border-orange-200/20",
    icon: "text-orange-100",
    title: "text-orange-200",
    line: "from-orange-200 via-amber-300 to-orange-500",
    terrain: "bg-[radial-gradient(circle_at_20%_28%,rgba(251,146,60,0.2),transparent_28%),linear-gradient(135deg,rgba(15,23,42,0.64),rgba(124,45,18,0.42))]",
  },
  {
    accent: "border-cyan-300/60 bg-cyan-300/[0.08]",
    base: "bg-[linear-gradient(135deg,rgba(8,47,73,0.94),rgba(13,78,94,0.7)),radial-gradient(circle_at_8%_18%,rgba(45,212,191,0.18),transparent_32%)]",
    gapGlow: "bg-gradient-to-r from-transparent via-cyan-300/35 to-transparent",
    glow: "shadow-[0_20px_64px_rgba(34,211,238,0.16)]",
    badge: "bg-cyan-300/15 text-cyan-100 border-cyan-200/20",
    icon: "text-cyan-100",
    title: "text-cyan-100",
    line: "from-cyan-200 via-teal-300 to-emerald-300",
    terrain: "bg-[radial-gradient(circle_at_18%_24%,rgba(45,212,191,0.2),transparent_30%),linear-gradient(135deg,rgba(8,47,73,0.72),rgba(20,83,45,0.38))]",
  },
  {
    accent: "border-emerald-300/60 bg-emerald-400/[0.08]",
    base: "bg-[linear-gradient(135deg,rgba(6,78,59,0.92),rgba(20,83,45,0.68)),radial-gradient(circle_at_8%_18%,rgba(52,211,153,0.16),transparent_32%)]",
    gapGlow: "bg-gradient-to-r from-transparent via-emerald-300/35 to-transparent",
    glow: "shadow-[0_20px_64px_rgba(16,185,129,0.15)]",
    badge: "bg-emerald-300/15 text-emerald-100 border-emerald-200/20",
    icon: "text-emerald-100",
    title: "text-emerald-100",
    line: "from-emerald-200 via-lime-300 to-green-400",
    terrain: "bg-[radial-gradient(circle_at_18%_26%,rgba(74,222,128,0.18),transparent_30%),linear-gradient(135deg,rgba(6,78,59,0.48),rgba(15,23,42,0.68))]",
  },
  {
    accent: "border-violet-300/55 bg-violet-500/[0.08]",
    base: "bg-[linear-gradient(135deg,rgba(46,16,101,0.92),rgba(88,28,135,0.62)),radial-gradient(circle_at_8%_18%,rgba(244,63,94,0.16),transparent_32%)]",
    gapGlow: "bg-gradient-to-r from-transparent via-violet-300/35 to-transparent",
    glow: "shadow-[0_20px_64px_rgba(190,24,93,0.16)]",
    badge: "bg-violet-300/15 text-violet-100 border-violet-200/20",
    icon: "text-violet-100",
    title: "text-violet-100",
    line: "from-violet-300 via-rose-300 to-red-400",
    terrain: "bg-[radial-gradient(circle_at_18%_24%,rgba(244,63,94,0.2),transparent_30%),linear-gradient(135deg,rgba(76,29,149,0.48),rgba(127,29,29,0.42))]",
  },
];

const personalityStyles: Partial<Record<string, RoutePersonality>> = {
  fastest: fallbackPersonalities[0],
  scenic: fallbackPersonalities[1],
  budget: fallbackPersonalities[2],
  adventure: fallbackPersonalities[3],
};

function getRoutePersonality(routeId: string, index: number) {
  return (
    personalityStyles[routeId] ??
    fallbackPersonalities[index % fallbackPersonalities.length]
  );
}

function ScoreChip({ label, score }: { label: string; score: number }) {
  return (
    <div className="rounded-2xl border border-white/12 bg-white/[0.09] px-3 py-2">
      <p className="text-[9px] font-black uppercase tracking-[0.12em] text-white/50">
        {label}
      </p>
      <div className="mt-1 flex items-center gap-2">
        <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/12">
          <div
            className="h-full rounded-full bg-gradient-to-r from-cyan-300 to-orange-400"
            style={{ width: `${score}%` }}
          />
        </div>
        <span className="text-xs font-black text-white">{score}</span>
      </div>
    </div>
  );
}

function budgetEstimate(routeOption: TiyaRouteOption) {
  const distanceValue = Number(routeOption.distance.match(/\d+/)?.[0] ?? 360);
  const multiplier =
    routeOption.id === "budget"
      ? 62
      : routeOption.id === "scenic"
        ? 92
        : routeOption.id === "adventure"
          ? 105
          : 82;
  const estimate = Math.max(
    9000,
    Math.round((distanceValue * multiplier) / 1000) * 1000
  );

  return `₹${estimate.toLocaleString("en-IN")} estimate`;
}

function transportHint(routeOption: TiyaRouteOption) {
  if (routeOption.routeStyle.toLowerCase().includes("rail")) return "Train + cab";
  if (routeOption.routeStyle.toLowerCase().includes("airport"))
    return "Flight + transfer";
  if (routeOption.id === "adventure") return "Bike / self-drive";
  if (routeOption.id === "scenic") return "Self-drive / cab";
  return "Best available mode";
}

function shortNote(note: string) {
  const [firstSentence] = note.split(".");
  return firstSentence ? `${firstSentence}.` : note;
}

function stopsHint(routeOption: TiyaRouteOption) {
  if (routeOption.id === "fastest") return "Minimal stops";
  if (routeOption.id === "scenic") return "Viewpoint halts";
  if (routeOption.id === "budget") return "Efficient stops";
  return "Terrain stops";
}

function permitHint(routeOption: TiyaRouteOption) {
  if (routeOption.riskLevel === "High") return "Permit/weather review";
  if (routeOption.id === "adventure") return "Terrain permit check";
  return "No major permit flag";
}

function routeCountLabel(count: number) {
  if (count <= 0) return "No smart routes generated yet";
  return `${count} smart route${count === 1 ? "" : "s"} available`;
}

function buildItineraryPreview(routeOption: TiyaRouteOption) {
  const style = routeOption.routeStyle.toLowerCase();
  const routeType =
    routeOption.id === "fastest" || style.includes("airport")
      ? "transfer"
      : routeOption.id === "scenic"
        ? "scenic halt"
        : routeOption.id === "budget"
          ? "value stop"
          : "terrain stop";

  return [
    `Day 1 -> Origin briefing + ${transportHint(routeOption)}`,
    `Day 2 -> Primary ${routeType}`,
    `Day 3 -> ${routeOption.bestFor}`,
    `Day 4 -> Local exploration + recovery window`,
    `Day 5 -> Arrival buffer + workspace refinement`,
  ];
}

function buildCostPreview(routeOption: TiyaRouteOption) {
  const distanceValue = Number(routeOption.distance.match(/\d+/)?.[0] ?? 360);
  const routeFactor =
    routeOption.id === "budget"
      ? 0.82
      : routeOption.id === "scenic"
        ? 1.08
        : routeOption.id === "adventure"
          ? 1.14
          : 1;
  const base = Math.max(8000, Math.round(distanceValue * 52 * routeFactor));

  return [
    ["Transport Estimate", base],
    ["Stay Estimate", Math.round(base * 0.72)],
    ["Activity Estimate", Math.round(base * 0.34)],
    ["Buffer / Misc Estimate", Math.round(base * 0.18)],
  ];
}

function buildRouteAlerts(routeOption: TiyaRouteOption) {
  return [
    `Weather: ${routeOption.riskLevel === "High" ? "review before departure" : "stable window expected"}`,
    `Permit: ${permitHint(routeOption)}`,
    `Terrain: ${routeOption.difficulty}`,
    `Risk: ${routeOption.riskLevel} route watch`,
    `Best season: verify live conditions in workspace`,
  ];
}

function buildStayPreview(routeOption: TiyaRouteOption) {
  if (routeOption.id === "budget") return ["Homestay", "Backpacker", "Value hotel"];
  if (routeOption.id === "scenic") return ["Boutique hotel", "Homestay", "Camp"];
  if (routeOption.id === "adventure") return ["Camp", "Terrain lodge", "Homestay"];
  return ["Hotel", "Premium stay", "Airport transfer stay"];
}

function buildExperiencePreview(routeOption: TiyaRouteOption) {
  if (routeOption.id === "scenic") return ["Scenic stopovers", "Hidden viewpoints", "Local food"];
  if (routeOption.id === "budget") return ["Local food", "Market walks", "Value activities"];
  if (routeOption.id === "adventure") return ["Terrain trails", "Creator stop", "Rugged viewpoints"];
  return ["Fast transfer", "City highlight", "Comfort stopover"];
}

function PreviewBlock({ title, items }: { title: string; items: string[] }) {
  return (
    <div className="rounded-2xl border border-sky-200/60 bg-white/70 p-3 shadow-[0_10px_28px_rgba(15,23,42,0.08)]">
      <p className="text-[10px] font-black uppercase tracking-[0.14em] text-slate-500">
        {title}
      </p>
      <div className="mt-2 flex flex-wrap gap-2">
        {items.map((item) => (
          <span
            key={`${title}-${item}`}
            className="rounded-full border border-sky-200 bg-sky-50 px-3 py-1.5 text-[11px] font-black text-slate-700"
          >
            {item}
          </span>
        ))}
      </div>
    </div>
  );
}

function RoutePreviewDetailPanel({
  routeOption,
  personality,
  activeTab,
  onTabChange,
  onContinue,
}: {
  routeOption: TiyaRouteOption;
  personality: RoutePersonality;
  activeTab: PreviewTab;
  onTabChange: (tab: PreviewTab) => void;
  onContinue: () => void;
}) {
  const costPreview = buildCostPreview(routeOption);

  return (
    <div className="border-t border-sky-200/55 bg-gradient-to-br from-sky-50 via-blue-50 to-slate-100 p-4 text-slate-950">
      <div className="rounded-[1.5rem] border border-sky-200/80 bg-white/78 p-4 shadow-[0_18px_54px_rgba(15,23,42,0.12)] backdrop-blur-xl">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <p className="text-[10px] font-black uppercase tracking-[0.16em] text-orange-600">
              Smart route detail
            </p>
            <h4 className="mt-1 text-2xl font-black text-slate-950">
              {routeOption.name} preview
            </h4>
            <p className="mt-1 text-sm font-bold text-slate-600">
              {shortNote(routeOption.note)}
            </p>
          </div>
          <span className="rounded-full border border-orange-200 bg-orange-50 px-3 py-1.5 text-xs font-black text-orange-700">
            {routeOption.bestFor}
          </span>
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          {previewTabs.map((tab) => (
            <button
              key={tab}
              type="button"
              onClick={() => onTabChange(tab)}
              className={`rounded-full border px-3 py-2 text-xs font-black transition ${
                activeTab === tab
                  ? "border-orange-300 bg-orange-500 text-white shadow-[0_10px_24px_rgba(249,115,22,0.24)]"
                  : "border-sky-200 bg-white/75 text-slate-700 hover:bg-sky-50"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        <div className="mt-4">
          {activeTab === "Overview" ? (
            <div className="grid gap-3 lg:grid-cols-[1fr_260px]">
              <div className="rounded-2xl border border-sky-200 bg-white/80 p-4">
                <p className="text-[10px] font-black uppercase tracking-[0.14em] text-slate-500">
                  Route summary
                </p>
                <h5 className="mt-2 text-xl font-black text-slate-950">
                  {routeOption.routeStyle}
                </h5>
                <p className="mt-2 text-sm font-bold leading-6 text-slate-700">
                  {routeOption.bestFor}. Tiya will open the full journey
                  workspace with editable itinerary, stays, creator hooks, and
                  booking modules after confirmation.
                </p>
              </div>
              <div className="grid gap-2">
                {[
                  ["Duration", routeOption.duration],
                  ["Budget", budgetEstimate(routeOption)],
                  ["Distance", routeOption.distance],
                  ["Risk", `${routeOption.riskLevel} risk`],
                ].map(([label, value]) => (
                  <div
                    key={label}
                    className="rounded-2xl border border-sky-200 bg-white/80 px-3 py-2"
                  >
                    <p className="text-[9px] font-black uppercase tracking-[0.12em] text-slate-500">
                      {label}
                    </p>
                    <p className="mt-1 text-sm font-black text-slate-950">
                      {value}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          ) : null}

          {activeTab === "Itinerary" ? (
            <div className="grid gap-2">
              {buildItineraryPreview(routeOption).map((item) => (
                <div
                  key={item}
                  className="flex items-center gap-2 rounded-2xl border border-sky-200 bg-white/80 px-3 py-2 text-sm font-bold text-slate-700"
                >
                  <span className={`h-2 w-2 rounded-full bg-gradient-to-r ${personality.line}`} />
                  {item}
                </div>
              ))}
            </div>
          ) : null}

          {activeTab === "Cost" ? (
            <div className="grid gap-3">
              <div className="grid gap-2 sm:grid-cols-4">
                {costPreview.map(([label, value]) => (
                  <div
                    key={label}
                    className="rounded-2xl border border-sky-200 bg-white/80 px-3 py-3"
                  >
                    <p className="text-[9px] font-black uppercase tracking-[0.12em] text-slate-500">
                      {label}
                    </p>
                    <p className="mt-1 text-base font-black text-slate-950">
                      ₹{Number(value).toLocaleString("en-IN")}
                    </p>
                  </div>
                ))}
              </div>
              <p className="rounded-xl border border-orange-200 bg-orange-50 px-3 py-2 text-xs font-bold text-orange-700">
                Live fares & inventory will load in workspace.
              </p>
            </div>
          ) : null}

          {activeTab === "Alerts" ? (
            <PreviewBlock title="Route intelligence alerts" items={buildRouteAlerts(routeOption)} />
          ) : null}

          {activeTab === "Stay" ? (
            <PreviewBlock title="Stay style preview" items={buildStayPreview(routeOption)} />
          ) : null}

          {activeTab === "Experiences" ? (
            <PreviewBlock title="Experience preview" items={buildExperiencePreview(routeOption)} />
          ) : null}

          {activeTab === "Creator" ? (
            <PreviewBlock
              title="Creator highlights"
              items={[
                "Creator recommended viewpoint",
                "Viral route stop",
                "Creator tip hook",
              ]}
            />
          ) : null}
        </div>

        <div className="mt-4 flex justify-end">
          <button
            type="button"
            onClick={onContinue}
            className="inline-flex min-h-12 items-center justify-center rounded-full bg-gradient-to-r from-[#ff7b00] via-[#ff9500] to-[#ffb300] px-6 py-3 text-sm font-black text-white shadow-[0_16px_38px_rgba(255,123,0,0.28)] transition hover:translate-y-[-1px]"
          >
            Continue with this Route
          </button>
        </div>
      </div>
    </div>
  );
}

export default function TiyaRouteIntelligence({
  routeOptions,
  isGenerating = false,
  selectedRouteId,
  selectionConfirmed = true,
  tripIntent,
  generatedPlan,
  onSelectedRouteChange,
}: TiyaRouteIntelligenceProps) {
  const router = useRouter();
  const safeRouteOptions = useMemo(
    () => (Array.isArray(routeOptions) ? routeOptions : []),
    [routeOptions]
  );

  const recommendedRoute = useMemo(
    () =>
      safeRouteOptions.find((route) => route.isRecommended) ??
      safeRouteOptions[0],
    [safeRouteOptions]
  );

  const [internalSelectedRouteId, setInternalSelectedRouteId] = useState(
    recommendedRoute?.id ?? "fastest"
  );
  const [compareRouteIds, setCompareRouteIds] = useState<
    TiyaRouteOption["id"][]
  >([]);
  const [isCompareOpen, setIsCompareOpen] = useState(false);
  const [expandedRouteId, setExpandedRouteId] = useState<
    TiyaRouteOption["id"] | null
  >(null);
  const [activePreviewTab, setActivePreviewTab] =
    useState<PreviewTab>("Overview");

  const activeSelectedRouteId = selectionConfirmed
    ? selectedRouteId ?? internalSelectedRouteId
    : undefined;

  const selectedRoute =
    safeRouteOptions.find((route) => route.id === activeSelectedRouteId) ??
    recommendedRoute ??
    safeRouteOptions[0];

  const selectedRouteIdForDisplay = selectedRoute?.id;

  const sortedRoutes = useMemo(() => {
    if (!selectedRouteIdForDisplay) return safeRouteOptions;

    const selected = safeRouteOptions.find(
      (route) => route.id === selectedRouteIdForDisplay
    );
    const otherRoutes = safeRouteOptions.filter(
      (route) => route.id !== selectedRouteIdForDisplay
    );

    return selected ? [selected, ...otherRoutes] : safeRouteOptions;
  }, [safeRouteOptions, selectedRouteIdForDisplay]);

  const validCompareRouteIds = compareRouteIds.filter((routeId) =>
    safeRouteOptions.some((route) => route.id === routeId)
  );

  const compareRoutes = safeRouteOptions.filter((routeOption) =>
    validCompareRouteIds.includes(routeOption.id)
  );

  const compareReady = compareRoutes.length >= 2;

  const routeContext =
    selectedRoute?.routeStyle ?? selectedRoute?.bestFor ?? "your Tiya trip";

  function selectRoute(routeId: TiyaRouteOption["id"]) {
    setInternalSelectedRouteId(routeId);
    onSelectedRouteChange?.(routeId);
  }

  function toggleCompare(routeId: TiyaRouteOption["id"]) {
    setCompareRouteIds((current) =>
      current.includes(routeId)
        ? current.filter((id) => id !== routeId)
        : [...current, routeId]
    );
  }

  function continueWithRoute(routeOption: TiyaRouteOption) {
    saveRouteWorkspacePayload(
      routeOption,
      safeRouteOptions,
      tripIntent,
      generatedPlan
    );
    router.push("/smart-planner/workspace");
  }

  return (
    <section className="overflow-hidden rounded-[2rem] border border-sky-100/35 bg-[#dff4ff] text-white shadow-[0_28px_100px_rgba(6,24,57,0.18)]">
      <div className="relative overflow-hidden rounded-[2rem] bg-[linear-gradient(135deg,#10284f_0%,#123d69_46%,#172033_100%)]">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_18%_8%,rgba(34,211,238,0.13),transparent_28%),radial-gradient(circle_at_90%_12%,rgba(249,115,22,0.16),transparent_25%)]" />

        <div className="relative border-b border-white/10 p-4 lg:p-5">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
            <div>
              <div className="flex items-center gap-2 text-[11px] font-black uppercase tracking-[0.18em] text-cyan-100">
                <Compass
                  size={15}
                  className={isGenerating ? "animate-pulse" : undefined}
                />
                Tiya travel intelligence
              </div>

              <h2 className="mt-2 text-2xl font-black tracking-normal text-white lg:text-3xl">
                Route Intelligence
              </h2>

              <p className="mt-1 max-w-2xl text-sm font-semibold leading-6 text-cyan-50/78">
                {routeCountLabel(safeRouteOptions.length)} for {routeContext}
              </p>

              <div className="mt-3 flex flex-wrap gap-2">
                <span className="rounded-full border border-orange-300/25 bg-orange-500/14 px-3 py-1.5 text-[11px] font-black text-orange-100">
                  Selected Route: {selectedRoute?.name ?? "Review pending"}
                </span>

                <span className="rounded-full border border-cyan-300/24 bg-cyan-300/12 px-3 py-1.5 text-[11px] font-black text-cyan-100">
                  AI Recommended: {recommendedRoute?.name ?? "Analyzing"}
                </span>

                <span
                  className={`rounded-full border px-3 py-1.5 text-[11px] font-black ${
                    validCompareRouteIds.length
                      ? "border-amber-300/40 bg-amber-400/16 text-amber-100"
                      : "border-white/14 bg-white/[0.08] text-white/62"
                  }`}
                >
                  Compare {validCompareRouteIds.length ? "Active" : "Ready"}
                </span>
              </div>
            </div>

            <div className="rounded-2xl border border-white/12 bg-white/[0.08] px-4 py-3 text-right shadow-sm">
              <p className="text-[10px] font-black uppercase tracking-[0.16em] text-white/46">
                Total Routes
              </p>
              <p className="mt-1 text-2xl font-black text-white">
                {safeRouteOptions.length}
              </p>
            </div>
          </div>

          {selectedRoute ? (
            <div className="relative mt-3 grid gap-2 sm:grid-cols-[1.15fr_repeat(3,minmax(0,1fr))]">
              <label className="rounded-xl border border-orange-300/24 bg-orange-500/12 px-3 py-2">
                <span className="text-[9px] font-black uppercase tracking-[0.14em] text-orange-100/75">
                  Selected Route
                </span>
                <select
                  value={selectedRouteIdForDisplay ?? ""}
                  onChange={(event) =>
                    selectRoute(event.target.value as TiyaRouteOption["id"])
                  }
                  className="mt-1 w-full cursor-pointer rounded-lg border border-orange-200/20 bg-[#fff7ed] px-2 py-1.5 text-xs font-black text-slate-950 outline-none transition focus:border-orange-400"
                >
                  {safeRouteOptions.map((routeOption) => (
                    <option
                      key={`selected-route-${routeOption.id}`}
                      value={routeOption.id}
                      className="bg-white text-slate-950"
                    >
                      {routeOption.name}
                    </option>
                  ))}
                </select>
              </label>

              {[
                ["Distance", selectedRoute.distance],
                ["Duration", selectedRoute.duration],
                ["Risk", selectedRoute.riskLevel],
              ].map(([label, value]) => (
                <div
                  key={label}
                  className="rounded-xl border border-white/10 bg-white/[0.08] px-3 py-2"
                >
                  <p className="text-[9px] font-black uppercase tracking-[0.14em] text-white/45">
                    {label}
                  </p>
                  <p className="mt-0.5 truncate text-xs font-black text-white">
                    {value}
                  </p>
                </div>
              ))}
            </div>
          ) : null}
        </div>

        {validCompareRouteIds.length ? (
          <div className="relative border-b border-white/10 px-4 py-3 lg:px-6">
            <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-orange-300/45 bg-gradient-to-r from-orange-500/24 via-amber-400/16 to-orange-500/10 px-4 py-3 shadow-[0_16px_44px_rgba(249,115,22,0.18)]">
              <p className="text-sm font-black text-orange-50">
                {validCompareRouteIds.length} routes selected for comparison
              </p>
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  disabled={!compareReady}
                  onClick={() => compareReady && setIsCompareOpen(true)}
                  className="inline-flex min-h-10 items-center justify-center rounded-full bg-gradient-to-r from-[#ff7b00] via-[#ff9500] to-[#ffb300] px-4 py-2 text-xs font-black text-white shadow-[0_14px_34px_rgba(255,123,0,0.22)] transition disabled:cursor-not-allowed disabled:bg-none disabled:bg-white/12 disabled:text-white/38 disabled:shadow-none"
                >
                  Compare Selected Routes
                </button>

                <button
                  type="button"
                  onClick={() => setCompareRouteIds([])}
                  className="inline-flex min-h-10 items-center justify-center rounded-full border border-white/20 bg-white/12 px-4 py-2 text-xs font-black text-white/80 transition hover:bg-white/18"
                >
                  Clear
                </button>
              </div>
            </div>
          </div>
        ) : null}

        <div className="relative grid gap-0 p-4 lg:p-6">
          {sortedRoutes.map((routeOption, index) => {
            const selected = selectedRouteIdForDisplay === routeOption.id;
            const expanded = selected && expandedRouteId === routeOption.id;
            const comparing = compareRouteIds.includes(routeOption.id);
            const personality = getRoutePersonality(routeOption.id, index);

            return (
              <div key={routeOption.id}>
                {index > 0 ? (
                  <div className="py-4">
                    <div
                      className={`h-px w-full ${personality.gapGlow}`}
                    />
                    <div className="mx-auto mt-[-1px] h-3 w-[70%] rounded-full bg-white/5 blur-xl" />
                  </div>
                ) : null}

                <article
                  className={`group relative overflow-hidden rounded-[1.65rem] border transition-all duration-300 ${
                    selected
                      ? `translate-y-[-2px] ${personality.base} ${personality.accent} ${personality.glow}`
                      : `border-white/18 ${personality.base} shadow-[0_22px_64px_rgba(2,6,23,0.24)] hover:-translate-y-0.5`
                  }`}
                >
                  <div className="pointer-events-none absolute inset-x-8 top-0 h-px bg-gradient-to-r from-transparent via-white/28 to-transparent" />
                  <div
                    className={`pointer-events-none absolute inset-y-5 left-0 w-1 rounded-r-full bg-gradient-to-b ${personality.line}`}
                  />

                  <div className="grid gap-4 p-4 lg:grid-cols-[minmax(0,1fr)_330px] lg:p-4">
                    <div className="min-w-0">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex min-w-0 items-center gap-3">
                          <div
                            className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border ${personality.badge}`}
                          >
                            <Route size={20} className={personality.icon} />
                          </div>

                          <div className="min-w-0">
                            <div className="flex flex-wrap items-center gap-2">
                              <h3
                                className={`text-2xl font-black leading-tight ${personality.title}`}
                              >
                                {routeOption.name}
                              </h3>

                              {routeOption.isRecommended ? (
                                <span className="inline-flex items-center gap-1 rounded-full border border-cyan-200/20 bg-cyan-300/16 px-2.5 py-1 text-[10px] font-black text-cyan-100 shadow-[0_0_24px_rgba(34,211,238,0.14)]">
                                  <Sparkles size={12} />
                                  Tiya recommends
                                </span>
                              ) : null}
                            </div>

                            <p className="mt-1 text-sm font-bold text-white/62">
                              {routeOption.routeStyle}
                            </p>
                          </div>
                        </div>

                        <span
                          className={`shrink-0 rounded-full border px-2.5 py-1 text-[11px] font-black ${riskStyles[routeOption.riskLevel]}`}
                        >
                          {routeOption.riskLevel} risk
                        </span>
                      </div>

                      <p className="mt-3 max-w-3xl text-sm font-semibold leading-6 text-white/72">
                        {shortNote(routeOption.note)}
                      </p>

                      <div className="mt-3 grid gap-2 lg:grid-cols-4">
                        <div>
                          <p className="text-[10px] font-black uppercase tracking-[0.14em] text-white/42">
                            Duration
                          </p>
                          <p className="mt-1 text-base font-black text-white">
                            {routeOption.duration}
                          </p>
                        </div>

                        <div className="min-w-0">
                          <p className="text-[10px] font-black uppercase tracking-[0.14em] text-white/42">
                            Budget
                          </p>
                          <p className="mt-1 truncate text-base font-black text-white">
                            {budgetEstimate(routeOption)}
                          </p>
                        </div>

                        <ScoreChip
                          label="Scenic"
                          score={routeOption.scenicScore}
                        />
                        <ScoreChip
                          label="Comfort"
                          score={routeOption.comfortScore}
                        />
                      </div>

                      <div className="mt-3 flex flex-wrap gap-2">
                        <span className="rounded-full border border-white/12 bg-white/[0.09] px-3 py-1.5 text-xs font-black text-white/76">
                          {routeOption.distance}
                        </span>
                        <span className="rounded-full border border-white/12 bg-white/[0.09] px-3 py-1.5 text-xs font-black text-white/76">
                          {routeOption.difficulty}
                        </span>
                        <span
                          className={`rounded-full border px-3 py-1.5 text-xs font-black ${personality.badge}`}
                        >
                          {transportHint(routeOption)}
                        </span>
                      </div>
                    </div>

                    <div
                      className={`relative overflow-hidden rounded-[1.4rem] border border-white/12 ${personality.terrain} p-3`}
                    >
                      <div className="absolute inset-x-8 top-10 h-16 rounded-[100%] border border-white/10" />
                      <div
                        className={`absolute left-6 right-6 top-1/2 h-1 -translate-y-1/2 rounded-full bg-gradient-to-r ${personality.line}`}
                      />

                      <div className="relative h-32">
                        <div className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 rounded-full bg-cyan-100 shadow-[0_0_24px_rgba(103,232,249,0.8)]" />
                        <div className="absolute left-[46%] top-[38%] h-5 w-5 rounded-full border border-white/60 bg-orange-300 shadow-[0_0_28px_rgba(251,146,60,0.72)]" />
                        <div className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 rounded-full bg-white shadow-[0_0_24px_rgba(255,255,255,0.65)]" />

                        <div className="absolute bottom-0 left-0 right-0 flex items-center justify-between text-[10px] font-black uppercase tracking-[0.14em] text-white/48">
                          <span>Origin</span>
                          <span>{routeOption.id}</span>
                          <span>Arrival</span>
                        </div>

                        <div className="absolute right-0 top-0 rounded-2xl border border-white/12 bg-black/24 px-3 py-2 text-xs font-black text-white/82 backdrop-blur">
                          {stopsHint(routeOption)}
                        </div>
                      </div>

                      <div className="mt-3 grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => toggleCompare(routeOption.id)}
                          className={`inline-flex min-h-10 items-center justify-center rounded-full border px-3 py-2 text-xs font-black transition ${
                            comparing
                              ? "border-cyan-200/45 bg-cyan-300/20 text-cyan-100 shadow-[0_0_20px_rgba(34,211,238,0.14)]"
                              : "border-white/16 bg-white/11 text-white/76 hover:bg-white/16"
                          }`}
                        >
                          {comparing ? "Added to Compare" : "Compare"}
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            if (expanded) {
                              setExpandedRouteId(null);
                              return;
                            }

                            selectRoute(routeOption.id);
                            setExpandedRouteId(routeOption.id);
                            setActivePreviewTab("Overview");
                          }}
                          className={`inline-flex min-h-10 items-center justify-center gap-2 rounded-full border px-3 py-2 text-xs font-black transition ${
                            expanded
                              ? "border-orange-300/45 bg-orange-500/18 text-orange-100"
                              : "border-white/16 bg-white/11 text-white/76 hover:bg-white/16"
                          }`}
                        >
                          {expanded ? "Hide Detail" : "View Detail"}
                        </button>
                      </div>
                    </div>
                  </div>

                  <div
                    className={`grid transition-[grid-template-rows,opacity] duration-500 ease-out ${
                      expanded
                        ? "grid-rows-[1fr] opacity-100"
                        : "grid-rows-[0fr] opacity-0"
                    }`}
                  >
                    <div className="overflow-hidden">
                      <RoutePreviewDetailPanel
                        routeOption={routeOption}
                        personality={personality}
                        activeTab={activePreviewTab}
                        onTabChange={setActivePreviewTab}
                        onContinue={() => continueWithRoute(routeOption)}
                      />
                    </div>
                  </div>
                </article>
              </div>
            );
          })}
        </div>

        <div className="relative border-t border-white/10 p-3 lg:p-4">
          <div className="flex flex-wrap gap-2">
            {safeRouteOptions.map((routeOption) => (
              <button
                key={`compare-${routeOption.id}`}
                type="button"
                onClick={() => selectRoute(routeOption.id)}
                className={`inline-flex min-h-9 items-center gap-2 rounded-full border px-3 py-2 text-xs font-black transition ${
                  selectedRouteIdForDisplay === routeOption.id
                    ? "border-orange-300/50 bg-orange-500/12"
                    : "border-white/12 bg-white/[0.08] hover:bg-white/12"
                }`}
              >
                <Mountain size={14} className="text-cyan-100" />
                <span className="text-white">{routeOption.name}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {isCompareOpen ? (
        <div className="fixed inset-0 z-[80] flex items-center justify-center overflow-y-auto bg-slate-950/72 p-8 backdrop-blur-md">
          <div className="flex max-h-[calc(100vh-64px)] w-full max-w-7xl flex-col overflow-hidden rounded-[2rem] border border-orange-300/24 bg-[linear-gradient(135deg,#10284f_0%,#123d69_48%,#172033_100%)] text-white shadow-[0_32px_120px_rgba(2,6,23,0.48)]">
            <div className="sticky top-0 z-10 flex shrink-0 items-center justify-between border-b border-white/10 bg-[#10284f]/95 p-4 backdrop-blur-xl">
              <div>
                <p className="text-[11px] font-black uppercase tracking-[0.18em] text-orange-100">
                  Tiya route comparison
                </p>
                <h3 className="mt-1 text-2xl font-black">Compare Routes</h3>
              </div>

              <button
                type="button"
                onClick={() => setIsCompareOpen(false)}
                className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-orange-200/25 bg-orange-500/15 text-orange-50 shadow-[0_10px_26px_rgba(249,115,22,0.16)] transition hover:bg-orange-500/25"
                aria-label="Close route comparison"
              >
                <X size={18} />
              </button>
            </div>

            <div className="min-h-0 flex-1 overflow-y-auto p-4">
              <div className="overflow-x-auto">
                <div
                  className="grid min-w-[760px] gap-3"
                  style={{
                    gridTemplateColumns: `repeat(${Math.max(
                      compareRoutes.length,
                      1
                    )}, minmax(220px, 1fr))`,
                  }}
                >
                  {compareRoutes.length === 0 ? (
                    <div className="rounded-3xl border border-white/12 bg-white/[0.07] p-5 text-sm font-bold text-white/72">
                      Select at least two routes to compare.
                    </div>
                  ) : null}

                  {compareRoutes.map((routeOption, index) => {
                    const personality = getRoutePersonality(
                      routeOption.id,
                      index
                    );
                    const selected = selectedRouteIdForDisplay === routeOption.id;

                    return (
                      <div
                        key={`modal-${routeOption.id}`}
                        className={`rounded-3xl border p-4 transition ${
                          selected
                            ? `${personality.base} ${personality.accent} shadow-[0_0_38px_rgba(255,123,0,0.18)]`
                            : `${personality.base} border-white/12`
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <h4 className={`text-lg font-black ${personality.title}`}>
                            {routeOption.name}
                          </h4>
                          {routeOption.isRecommended ? (
                            <Sparkles size={16} className="text-cyan-100" />
                          ) : null}
                        </div>

                        <p className="mt-1 text-xs font-bold text-white/58">
                          {routeOption.bestFor}
                        </p>

                        <div className="mt-4 grid gap-2 text-xs font-bold text-white/74">
                          {[
                            ["Duration", routeOption.duration],
                            ["Distance", routeOption.distance],
                            ["Budget", budgetEstimate(routeOption)],
                            ["Scenic", `${routeOption.scenicScore}`],
                            ["Comfort", `${routeOption.comfortScore}`],
                            ["Difficulty", routeOption.difficulty],
                            ["Stops", stopsHint(routeOption)],
                            ["Weather risk", routeOption.riskLevel],
                            ["Permits", permitHint(routeOption)],
                            ["Transport", transportHint(routeOption)],
                            ["Route vibe", routeOption.routeStyle],
                            [
                              "AI recommendation",
                              routeOption.isRecommended
                                ? "Recommended by Tiya"
                                : "Alternative fit",
                            ],
                          ].map(([label, value]) => (
                            <div
                              key={`${routeOption.id}-${label}`}
                              className="rounded-2xl border border-white/10 bg-white/[0.08] px-3 py-2"
                            >
                              <p className="text-[9px] font-black uppercase tracking-[0.12em] text-white/42">
                                {label}
                              </p>
                              <p className="mt-1 text-white">{value}</p>
                            </div>
                          ))}
                        </div>

                        <button
                          type="button"
                          onClick={() => {
                            selectRoute(routeOption.id);
                            setIsCompareOpen(false);
                          }}
                          className={`mt-4 inline-flex min-h-10 w-full items-center justify-center rounded-full px-4 py-2 text-xs font-black transition ${
                            selected
                              ? "bg-gradient-to-r from-[#ff7b00] via-[#ff9500] to-[#ffb300] text-white shadow-[0_12px_28px_rgba(255,123,0,0.24)]"
                              : "border border-white/16 bg-white/11 text-white hover:bg-white/16"
                          }`}
                        >
                          {selected ? "Selected Route" : "Select this Route"}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </section>
  );
}
